import { findUser } from "../../lib/users.js";
import { convertToJid, sendMessageWithMention } from "../../lib/utils.js";

async function handle(sock, messageInfo) {
  const {
    remoteJid,
    message,
    content,
    sender,
    senderType,
  } = messageInfo;

  let target = content?.trim();
  let targetJid = sender;

  // ─── Cek money diri sendiri ───
  if (!target) {
    const dataUsers = await findUser(sender);

    if (!dataUsers) {
      return sock.sendMessage(
        remoteJid,
        { text: "⚠️ _Data kamu belum terdaftar di database_" },
        { quoted: message }
      );
    }

    const [, userData] = dataUsers;

    return sendMessageWithMention(
      sock,
      remoteJid,
      `💰 *CEK MONEY*\n\n👤 User: @${sender.split("@")[0]}\n💵 Money: *${userData.money || 0}*`,
      message,
      senderType
    );
  }

  // ─── Cek money user lain ───
  let dataUsers = await findUser(target);
  targetJid = target;

  if (!dataUsers) {
    const r = await convertToJid(sock, target);
    targetJid = r;
    dataUsers = await findUser(r);

    if (!dataUsers) {
      return sock.sendMessage(
        remoteJid,
        { text: `⚠️ _User ${target} tidak ditemukan di database_` },
        { quoted: message }
      );
    }
  }

  const [, userData] = dataUsers;

  // ─── Kirim hasil ───
  await sendMessageWithMention(
    sock,
    remoteJid,
    `💰 *CEK MONEY*\n\n👤 User: @${targetJid.split("@")[0]}\n💵 Money: *${userData.money || 0}*`,
    message,
    senderType
  );
}

export default {
  handle,
  Commands: ["cekmoney"],
  OnlyAdmin: true,
  OnlyPremium: false,
};
